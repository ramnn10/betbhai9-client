import  { useEffect } from 'react';
import './counter.css'

function CustomReactFlipCounter({ count }) {
  const minutes = Math.floor(count / 10);
  const seconds = count % 10; 

  useEffect(() => {
    updateDisplay(minutes, 'minutePlay');
    updateDisplay(seconds, 'secondPlay');
  }, [minutes, seconds]);
  const updateDisplay = (digit, className) => {
    document.body.classList.remove("play");
    const listItems = document.querySelectorAll(`ul.${className} li`);
    listItems.forEach(item => {
      item.classList?.remove("before", "active");
    });
    const activeItem = listItems[digit];
    activeItem?.classList.add("active");
    if (digit === 9) {
      listItems[0]?.classList.add("before");
    } else {
      listItems[digit + 1]?.classList.add("before");
    }
    document.body.classList?.add("play");
  };
  
  return (
    <>
      <ul className="flip minutePlay">
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <li key={num}>
            <a href="#">
              <div className="up">
                <div className="shadow"></div>
                <div className="inn">{num}</div>
              </div>
              <div className="down">
                <div className="shadow"></div>
                <div className="inn">{num}</div>
              </div>
            </a>
          </li>
        ))}
      </ul>
      <ul className="flip secondPlay">
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <li key={num}>
            <a href="#">
              <div className="up">
                <div className="shadow"></div>
                <div className="inn">{num}</div>
              </div>
              <div className="down">
                <div className="shadow"></div>
                <div className="inn">{num}</div>
              </div>
            </a>
          </li>
        ))}
      </ul>
    </>
  );
}

export default CustomReactFlipCounter;